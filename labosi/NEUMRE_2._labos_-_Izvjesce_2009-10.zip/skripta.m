b1 = real('vrat')'
b2 = real('kraj')';
b3 = real('cres')';
b4 = real('otac')';

a1 = [1,0,0,0]';
a2 = [0,1,0,0]';
a3 = [0,0,1,0]';
a4 = [0,0,0,1]';

M = b1 * a1' + b2 * a2' + b3 * a3' + b4 * a4'

setstr(M * a1)'
setstr(M * a2)'
setstr(M * a3)'
setstr(M * a4)'

%%
a5 = (a1 + a3) / sqrt(2)
b5 = real('mrak')';
M = M + b5 * a5'

setstr(M * a1)'
setstr(M * a2)'
setstr(M * a3)'
setstr(M * a4)'
setstr(M * a5)'

%%
a1 = real('ruka')';
a2 = real('kset')';
a3 = real('more')';
a4 = real('mama')';

M = b1 * a1' + b2 * a2' + b3 * a3' + b4 * a4'

setstr(M * a1)'
setstr(M * a2)'
setstr(M * a3)'
setstr(M * a4)'
setstr(M * a5)'

%%
A = [a1, a2, a3, a4];

C = orth(A);
c1 = C(1,:)'
c2 = C(2,:)'
c3 = C(3,:)'
c4 = C(4,:)'

M = b1 * c1' + b2 * c2' + b3 * c3' + b4 * c4'

char(round(M * c1))'
char(round(M * c2))'
char(round(M * c3))'
char(round(M * c4))'

%%
B = [b1, b2, b3, b4];

M = B * inv(A)

char(round(M * a1))'
char(round(M * a2))'
char(round(M * a3))'
char(round(M * a4))'

%%
A = [a1, a2, a3, a4, a5];
B = [b1, b2, b3, b4, b5];

A_pi = A' * inv(A*A')
M = B*A_pi

out1 = char(round(M * a1))'
out2 = char(round(M * a2))'
out3 = char(round(M * a3))'
out4 = char(round(M * a4))'
out5 = char(round(M * a5))'

e1 = b1 - out1'
e2 = b2 - out2'
e3 = b3 - out3'
e4 = b4 - out4'
e5 = b5 - out5'

%%
A = [a1, a2, a3, a4];
B = [b1, b2, b3, b4];

char(A)'
char(B)'

ni = 0.9999/max(eig(A*A'))

j = 0;
for max_br_iter = 1000:1000:40000
    M = -0.5 + rand(4,4);
    [M, e] = trainlms(ni, A, B, M, max_br_iter);
    j = j + 1;
    br_zapamcenih(j) = sum( sum( round(M*A)'==B') );
end

i=1:j;
stem(1000:1000:40000,br_zapamcenih(i));
title('Graf ovisnosti broja zapamcenih slova o broju koristenih iteracija')
xlabel('broj iteracija')
ylabel('broj zapamcenih slova')

char(round(M*A))'
round(M*A)' == B'
figure
loglog(e)
title('Graf ovisnosti pogreske o broju iteracija')
xlabel('redni broj iteracije')
ylabel('iznos pogreske')

%%
a5 = real('auto')';
b5 = real('mrak')';

A = [a1, a2, a3, a4, a5];
B = [b1, b2, b3, b4, b5];

M = -0.5 + rand(4,4);
[M, e] = trainlms(ni, A, B, M, 4000);
sum( sum( round(M*A)'==B') )

out1 = char(round(M * a1))';
out2 = char(round(M * a2))';
out3 = char(round(M * a3))';
out4 = char(round(M * a4))';
out5 = char(round(M * a5))';

e1 = (b1 - out1').^2;
e2 = (b2 - out2').^2;
e3 = (b3 - out3').^2;
e4 = (b4 - out4').^2;
e5 = (b5 - out5').^2;

sum(e1) + sum(e2) + sum(e3) + sum(e4) + sum(e5)

[M, e] = trainlms(ni, A, B, M, 4000);
sum( sum( round(M*A)'==B') )

out1 = char(round(M * a1))';
out2 = char(round(M * a2))';
out3 = char(round(M * a3))';
out4 = char(round(M * a4))';
out5 = char(round(M * a5))';

e1 = (b1 - out1').^2;
e2 = (b2 - out2').^2;
e3 = (b3 - out3').^2;
e4 = (b4 - out4').^2;
e5 = (b5 - out5').^2;

sum(e1) + sum(e2) + sum(e3) + sum(e4) + sum(e5)