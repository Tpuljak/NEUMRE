function [out, err] = trainlms(ni, A, B, M, max_br_epoha)
% Funkcija predstavlja implementaciju Widrow-Hoff LMS algoritma za učenje
% max_br_iter - broj iteracija učenja
% ni          - konstanta učenja (procjena: ni = 0.9999/max(eig(p*p'));)
% B je ciljana vrijednost
% A je ulazni vektor
% M je matrica transformacije
% izlazi su out - nova matrica transvormacije
%           err - vektor promjene pogreške za svaku iteracije
% funkcija završava ukoliko se dosegne max_br_epoha ili ukoliko pogreška
% padne ispod 0.02

% $Revizija: 1.0 $  $Datum: 2009/09/09 14:48 $
% $Autor(i): Hrvoje Kalinić $

d = B;
x = A;
w = M;


n = 0;  % broji epohe

while n < max_br_epoha % ponavljati epohe dok se ne prijeđe maksimalan broj epoha
    n = n + 1; 
    
    e = d - w*x;                % računanje pogreške
    w = w + ni * e * x';        % korekcija težine

    err(n) = sum(sum(e.*e));
%    plot(err)
    
    if err(n) < 0.02 % prekinuti ukoliko se dostigne dovoljno mala pogreška
        break
    end
end

out = w;

